package com.example.emptyviewactivity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText fullname, emailid, password;
    Button register_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fullname = findViewById(R.id.fullname);
        emailid = findViewById(R.id.emailid);
        password = findViewById(R.id.password);
        register_btn = findViewById(R.id.register_btn);

        register_btn.setOnClickListener(view -> {
            String fullname_text = fullname.getText().toString().trim();
            String emailid_text = emailid.getText().toString().trim();
            String password_text = password.getText().toString().trim();

            // Password pattern: At least 6 chars with 1 digit, 1 letter, 1 special char
            String password_regex = "^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[@#$%^&+=]).{6,}$";

            if (fullname_text.isEmpty()) {
                fullname.setError("Full name is required!");
                fullname.requestFocus();
                return;
            }

            if (emailid_text.isEmpty()) {
                emailid.setError("Email is required!");
                emailid.requestFocus();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(emailid_text).matches()) {
                emailid.setError("Please enter a valid email!");
                emailid.requestFocus();
                return;
            }

            if (password_text.isEmpty()) {
                password.setError("Password is required!");
                password.requestFocus();
                return;
            }

            if (!password_text.matches(password_regex)) {
                password.setError("Password must contain:\n" +
                        "• At least 6 characters\n" +
                        "• At least 1 digit\n" +
                        "• At least 1 letter\n" +
                        "• At least 1 special character (@#$%^&+=)");
                password.requestFocus();
                return;
            }

            // Save data to SharedPreferences
            SharedPreferences pref = getSharedPreferences("register_data", MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("reg_fullname", fullname_text);
            editor.putString("reg_emailid", emailid_text);
            editor.putString("reg_password", password_text);
            editor.apply();

            Toast.makeText(MainActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();

            // Start new activity
            Intent intent = new Intent(MainActivity.this, emptyviewactivity.class);
            startActivity(intent);
            finish(); // Optional: close this activity
        });
    }
}